
    <footer class="footer space-ptb bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-6 mb-5 mb-lg-0">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">IT Services</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-3 mb-sm-0">
                <li><a href="website-development.php">Website Development</a></li>
                <li><a href="digital-marketing.php">Digital Marketing</a></li>
                <li><a href="search-engine-optimization.php">Search Engine Optimization</a></li>
                <li><a href="branding.php">Branding</a></li>
              </ul>
              <ul class="list-unstyled mb-3 mb-sm-0">
                <li><a href="email-marketing.php">Email Marketing</a></li>
                <li><a href="#"></a></li>
                <li><a href="ecommerce-website.php">E-Commerce Website</a></li>
                <li><a href="start-up.php">Start-up Ideas</a></li>
              </ul>
              <ul class="list-unstyled mb-0">
                <li><a href="social-media.php">Social Media Growth</a></li>
                <li><a href="social-media.php">Social Media Engagement</a></li>
                <li><a href="social-media.php">Social Media Management</a></li>
                <li><a href="#"></a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3 mb-5 mb-sm-0">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Company</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-0">
                <li><a href="about-us.php">About</a></li>
                <li><a href="our-team.php">Our Team</a></li>
                <li><a href="blog.php">Company News</a></li>
                <li><a href="https://webdeves.com/blog/">Blog</a></li>
                <li><a href="careers.php">Careers <span class="badge badge-success ml-2">We're hiring</span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Support</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-0">
                <li><a href="https://wa.me/2348099111234?text=Hello%0AI%20want%20to%20know%20more%20about%20the%20Webdeves.%0AMy%20name%20is%20-">Chat with us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="pricing.php">Pricing And Plans</a></li>
                <li><a href="internship-webdeves.php">Internship</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 mt-5">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Social</h5>
            <ul class="list-unstyled social-icon">
              <li><a href="https://facebook.com/webdevestech"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="https://twitter.com/webdevestech"><i class="fab fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/in/webdeves-technologies-b073001aa"><i class="fab fa-linkedin-in"></i></a></li>
              <li><a href="https://www.instagram.com/webdeves"><i class="fab fa-instagram"></i></a></li>
            </ul>
             <p class="mb-0 text-white mt-4">© Copyright 2018 - 2025 <a href="index.php" style="color: #ff8c00">Webdeves Technologies</a> All Rights Reserved</p>
          </div>
          <div class="col-sm-6 mt-5">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Where we are</h5>
            <div class="d-flex align-items-center mb-3">
              <img class="img-fluid flag-svg" src="images/svg/Nigeria.png" alt="">
              <div class="ml-4">
                <h6 class="mb-0 text-white">56 Azikiwe Rd, beside Union Bank, Aba, Abia State</h6>
              </div>
            </div>
            <div class="d-flex align-items-center">
              <img class="img-fluid flag-svg" src="images/svg/usa.svg" alt="">
              <div class="ml-4">
                <h6 class="mb-0 text-white">214 West Arnold St. New York, NY 10002</h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
